RIYA BIRTHDAY WEBSITE — ENHANCED VERSION ❤️

WHAT'S INCLUDED
- Mobile-friendly romantic design
- Login screen
- Your original six photos preserved
- Birthday countdown to 20 October (automatically counts to the next upcoming 20 October)
- Love letter, memories, photo zoom/lightbox, floating hearts, final surprise reveal
- Original filenames preserved as photo1.jpg through photo6.jpg

LOGIN (same as the original site)
ID: riya
Password: 20october

HOW TO PREVIEW
1. Extract this ZIP.
2. Open the Riya-Birthday-20Oct-main folder.
3. Double-click index.html to open in Chrome.
4. Enter ID riya and password 20october.

HOW TO UPDATE YOUR GITHUB REPOSITORY
1. Keep a backup of the current repository first (download its ZIP).
2. Extract this ZIP on your laptop.
3. Open your existing GitHub repository.
4. Upload/replace index.html and the six photo files if GitHub shows the filenames differ by capitalisation.
5. Commit the changes.
6. Wait for GitHub Pages to redeploy, then open your existing Pages URL on mobile and test login, all photos, countdown and surprise.

IMPORTANT PRIVACY NOTE
The login is a front-end password gate, not real security. Anyone who can inspect the public HTML can find the ID/password and access the images. A public GitHub Pages site does not keep photos private. Avoid uploading intimate or highly private photos. For genuine private access, use a backend/auth service and protected storage.
